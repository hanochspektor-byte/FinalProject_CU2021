package com.example.finalproject_cu;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

public class SignInPage extends AppCompatActivity {
EditText userName, password;
TextView userNameError, passwordError;
CuDB cuDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_page);
        cuDB = new CuDB(this);
        password= findViewById(R.id.password);
        userName= findViewById(R.id.userName);
        passwordError= findViewById(R.id.passwordError);
        userNameError= findViewById(R.id.userNameError);
    }

    public void submit(View view) {
        if (TextUtils.isEmpty(userName.getText().toString())) {
            userNameError.setText("אנא הכנס שם משתמש תקין.");
        } else {
            userNameError.setText("");
        }
        if (TextUtils.isEmpty(password.getText().toString()) || password.getText().toString().length() != 8) {
            passwordError.setText("אנא הכנס סיסמה תקינה בארוך 8 מספרים.");
        } else {
            passwordError.setText("");
        }

        if(userNameError.getText().toString() == "" && passwordError.getText().toString() == "")
        {
            String user = userName.getText().toString();
            ArrayList<String> passVol = cuDB.selectPasswordByUserName("volunteerUsers", user);
            ArrayList<String> passAdult = cuDB.selectPasswordByUserName("adultUsers", user);
            String pass = password.getText().toString();

            if(!passVol.isEmpty()&&passVol.get(0).equals(pass)){
                ArrayList<String> name = cuDB.selectNameByUserName("volunteerUsers", user);
                ArrayList<String> place = cuDB.selectByUserName("volunteerUsers", "Address", user);
                SharedPreferences sharedpreferences = getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putString("userName", user);
                editor.putString("name", name.get(0));
                editor.putBoolean("isOld", false);
                editor.putString("place", place.get(0));
                editor.commit();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            }
            if(!passAdult.isEmpty()&&passAdult.get(0).equals(pass)){
                ArrayList<String> name = cuDB.selectNameByUserName("adultUsers", user);
                ArrayList<String> place = cuDB.selectByUserName("adultUsers", "Address", user);
                SharedPreferences sharedpreferences = getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putString("userName", user);
                editor.putString("name", name.get(0));
                editor.putBoolean("isOld", true);
                editor.putString("place", place.get(0));
                editor.commit();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            }
            if(passAdult.isEmpty()&&passVol.isEmpty())
            {Toast.makeText(this,"שם המשתמש או הסיסמה אינם נכונים", Toast.LENGTH_LONG).show();}
        }
    }

    public void cancel(View view) {
        finish();
    }
}