package com.example.finalproject_cu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class AlertsSettings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alerts_settings);
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_for_alerts_settings,menu);
        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.item1)
        {
            Intent intent= new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        if (id == R.id.item2)
        {
            Intent intent= new Intent(this, NewMeeting.class);
            startActivity(intent);
        }
        if (id == R.id.item3)
        {
            Intent intent= new Intent(this, MyMeetings.class);
            startActivity(intent);
        }
        if (id == R.id.item4)
        {
            Intent intent= new Intent(this, MyDetails.class);
            startActivity(intent);
        }
        if (id == R.id.logOut)
            finish();
        //לבקו מה עושים אם זה נמצא בעמוד שלפניו זה לא יוצא!!!
        return true;
    }
}