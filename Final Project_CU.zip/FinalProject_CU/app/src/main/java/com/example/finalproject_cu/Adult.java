package com.example.finalproject_cu;

import android.graphics.Bitmap;

public class Adult extends User {

    private String familyStatus;
    private String activityPreferring;
    private String needsHelpIn;

    public Adult(String name, String phone, String mail, String birthDate, String userName, String password, String language, String address, byte[] photo, String familyStatus, String activityPreferring, String needsHelpIn)
    {
        super(name, phone, mail, birthDate, userName, password, language, address, photo);
        this.familyStatus= familyStatus;
        this.activityPreferring= activityPreferring;
        this.needsHelpIn= needsHelpIn;
    }

    public String getFamilyStatus() {
        return familyStatus;
    }

    public String getActivityPreferring() {
        return activityPreferring;
    }

    public String getNeedsHelpIn() {
        return needsHelpIn;
    }
}
