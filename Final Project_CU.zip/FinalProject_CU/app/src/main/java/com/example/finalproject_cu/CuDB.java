package com.example.finalproject_cu;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class CuDB extends SQLiteOpenHelper {

    private static final String DB_NAME = "cu_database.db";
    private static final String VOLUNTEER_TABLE_NAME = "volunteerUsers";
    private static final String ADULT_TABLE_NAME = "adultUsers";


    private static final String COLUMN_NAME = "Name";
    private static final String COLUMN_PHONE = "PhoneNumber";
    private static final String COLUMN_EMAIL = "Email";
    private static final String COLUMN_AGE = "Age";
    private static final String COLUMN_USERNAME = "UserName";
    private static final String COLUMN_PASSWORD = "Password";
    private static final String COLUMN_LANGUGES = "Languges";
    private static final String COLUMN_ADDRESS = "Address";
    private static final String COLUMN_PHOTO = "Photo";

    private static final String COLUMN_FAMILY_STATUS = "FamilyStatus";
    private static final String COLUMN_ACTIVITY_PREFERRING = "ActivitiesPreferring";
    private static final String COLUMN_NEEDS_HELP = "NeedsHelp";

    private static final String COLUMN_HOURS_EACH_TIME = "HoursPerMeeting";
    private static final String COLUMN_DAYS_PER_WEEK = "DaysPerWeek";
    private static final String COLUMN_GIVE_HELP = "GiveHelp";

    @Override
    public void onCreate(SQLiteDatabase db) {
        String string = "CREATE TABLE IF NOT EXISTS "+ VOLUNTEER_TABLE_NAME +"(";
        string += COLUMN_NAME +" TEXT, ";
        string += COLUMN_PHONE +" TEXT, ";
        string += COLUMN_EMAIL +" TEXT, ";
        string += COLUMN_AGE +" TEXT, ";
        string += COLUMN_USERNAME +" TEXT PRIMARY KEY, ";
        string += COLUMN_PASSWORD +" TEXT, ";
        string += COLUMN_LANGUGES +" TEXT, ";
        string += COLUMN_ADDRESS +" TEXT, ";
        string += COLUMN_PHOTO +" BLOB, ";
        string += COLUMN_HOURS_EACH_TIME +" TEXT, ";
        string += COLUMN_DAYS_PER_WEEK +" TEXT, ";
        string += COLUMN_GIVE_HELP +" TEXT);";

        String string2 = "CREATE TABLE IF NOT EXISTS "+ ADULT_TABLE_NAME +"(";
        string2 += COLUMN_NAME +" TEXT, ";
        string2 += COLUMN_PHONE +" TEXT, ";
        string2 += COLUMN_EMAIL +" TEXT, ";
        string2 += COLUMN_AGE +" TEXT, ";
        string2 += COLUMN_USERNAME +" TEXT PRIMARY KEY, ";
        string2 += COLUMN_PASSWORD +" TEXT, ";
        string2 += COLUMN_LANGUGES +" TEXT, ";
        string2 += COLUMN_ADDRESS +" TEXT, ";
        string2 += COLUMN_PHOTO +" BLOB, ";
        string2 += COLUMN_FAMILY_STATUS +" TEXT, ";
        string2 += COLUMN_ACTIVITY_PREFERRING +" TEXT, ";
        string2 += COLUMN_NEEDS_HELP +" TEXT);";

        db.execSQL(string);
        db.execSQL(string2);
    }

    public CuDB(@Nullable Context context)
    {
        super(context, DB_NAME, null, 1);
}

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public void insertToAdult(Adult adult)
    {
        SQLiteDatabase database = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, adult.getName());
        values.put(COLUMN_PHONE, adult.getPhone());
        values.put(COLUMN_EMAIL, adult.getMail());
        values.put(COLUMN_AGE, adult.getAge());
        values.put(COLUMN_USERNAME, adult.getUserName());
        values.put(COLUMN_PASSWORD, adult.getPassword());
        values.put(COLUMN_LANGUGES, adult.getLanguage());
        values.put(COLUMN_ADDRESS, adult.getAddress());
        values.put(COLUMN_PHOTO, adult.getPhoto());
        values.put(COLUMN_ACTIVITY_PREFERRING, adult.getActivityPreferring());
        values.put(COLUMN_NEEDS_HELP, adult.getNeedsHelpIn());
        values.put(COLUMN_FAMILY_STATUS, adult.getFamilyStatus());
        database.insert(ADULT_TABLE_NAME, null ,values);
        database.close();
    }


    public void insertToVolunteer(Volunteer volunteer)
    {
        SQLiteDatabase database = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, volunteer.getName());
        values.put(COLUMN_PHONE, volunteer.getPhone());
        values.put(COLUMN_EMAIL, volunteer.getMail());
        values.put(COLUMN_AGE, volunteer.getAge());
        values.put(COLUMN_USERNAME, volunteer.getUserName());
        values.put(COLUMN_PASSWORD, volunteer.getPassword());
        values.put(COLUMN_LANGUGES, volunteer.getLanguage());
        values.put(COLUMN_ADDRESS, volunteer.getAddress());
        values.put(COLUMN_PHOTO, volunteer.getPhoto());
        values.put(COLUMN_HOURS_EACH_TIME, volunteer.getHoursEachTime());
        values.put(COLUMN_DAYS_PER_WEEK, volunteer.getDaysPerWeek());
        values.put(COLUMN_GIVE_HELP, volunteer.getGiveHelpIn());
        database.insert(VOLUNTEER_TABLE_NAME, null ,values);
        database.close();
    }


    public ArrayList<String> selectPasswordByUserName(String tableName, String userName) {
        SQLiteDatabase db = getReadableDatabase();
        String[] selectionArgs = {userName};
        ArrayList<String> password = new ArrayList<String>();
        Cursor cursor = db.rawQuery("SELECT "+COLUMN_PASSWORD+" FROM "+tableName+" WHERE "+COLUMN_USERNAME+ " = ?",selectionArgs);
        int num = cursor.getCount();
        if(num>0)
        {
            cursor.moveToLast();
            for (int i = 0; i < num; i++) {
                password.add(cursor.getString(cursor.getColumnIndex(COLUMN_PASSWORD)));
                cursor.moveToNext();
            }
        }
        db.close();
        return password;
    }


    public ArrayList<String> selectAdultUserName()
    {
        SQLiteDatabase database = getReadableDatabase();
        ArrayList<String> userNamesArr = new ArrayList<String>();
        Cursor cursor = database.query(ADULT_TABLE_NAME, null, null, null ,null ,null ,null);
        int num = cursor.getCount();
        cursor.moveToFirst();
        for (int i=0;i <num; i++)
        {
            userNamesArr.add(cursor.getString(cursor.getColumnIndex(COLUMN_USERNAME)));
            cursor.moveToNext();
        }
        database.close();
        return userNamesArr;
    }

    public ArrayList<String> selectVolunteerUserName()
    {
        SQLiteDatabase database = getReadableDatabase();
        ArrayList<String> userNamesArr = new ArrayList<String>();
        Cursor cursor = database.query(VOLUNTEER_TABLE_NAME, null, null, null ,null ,null ,null);
        int num = cursor.getCount();
        cursor.moveToFirst();
        for (int i=0;i <num; i++)
        {
            userNamesArr.add(cursor.getString(cursor.getColumnIndex(COLUMN_USERNAME)));
            cursor.moveToNext();
        }
        database.close();
        return userNamesArr;
    }

    public ArrayList<String> selectNameByUserName(String tableName, String userName)
    {
        SQLiteDatabase db = getReadableDatabase();
        String[] selectionArgs = {userName};
        ArrayList<String> password = new ArrayList<String>();
        Cursor cursor = db.rawQuery("SELECT "+COLUMN_NAME+" FROM "+tableName+" WHERE "+COLUMN_USERNAME+ " = ?",selectionArgs);
        int num = cursor.getCount();
        if(num>0)
        {
            cursor.moveToLast();
            for (int i = 0; i < num; i++) {
                password.add(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
                cursor.moveToNext();
            }
        }
        db.close();
        return password;
    }

    public ArrayList<String> selectByUserName(String tableName, String columnName, String userName)
    {
        SQLiteDatabase db = getReadableDatabase();
        String[] selectionArgs = {userName};
        ArrayList<String> arrayList = new ArrayList<String>();
        Cursor cursor = db.rawQuery("SELECT "+columnName+" FROM "+tableName+" WHERE "+COLUMN_USERNAME+ " = ?",selectionArgs);
        int num = cursor.getCount();
        if(num>0)
        {
            cursor.moveToLast();
            for (int i = 0; i < num; i++) {
                arrayList.add(cursor.getString(cursor.getColumnIndex(columnName)));
                cursor.moveToNext();
            }
        }
        db.close();
        return arrayList;
    }

    public ArrayList<Meeting> selectAllForListView(String tableNme, String qe1, String qe2)
    {
        SQLiteDatabase dt= this.getReadableDatabase();
        ArrayList<Meeting> data = new ArrayList<>();
        Cursor cursor=dt.query(tableNme,null,null,null,null,null,null);
        int num=cursor.getCount();
        cursor.moveToFirst();
        for(int i=0;i<num;i++)
        {
            byte[] photo = cursor.getBlob(cursor.getColumnIndex(COLUMN_PHOTO));
            String name = cursor.getString(cursor.getColumnIndex(COLUMN_NAME));
            String age = cursor.getString(cursor.getColumnIndex(COLUMN_AGE));
            String phone = cursor.getString(cursor.getColumnIndex(COLUMN_PHONE));
            String mail = cursor.getString(cursor.getColumnIndex(COLUMN_EMAIL));
            String place = cursor.getString(cursor.getColumnIndex(COLUMN_ADDRESS));
            String q1 = cursor.getString(cursor.getColumnIndex(qe1));
            String q2 = cursor.getString(cursor.getColumnIndex(qe2));
            String userName = cursor.getString(cursor.getColumnIndex(COLUMN_USERNAME));
            Meeting temp = new Meeting(photo, name, age, phone, mail, place, q1, q2,userName);
            data.add(temp);
            cursor.moveToNext();
        }
        dt.close();
        return data;

    }

}
