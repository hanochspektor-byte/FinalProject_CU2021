package com.example.finalproject_cu;

import android.graphics.Bitmap;

public class User {
    protected String name;
    protected String phone;
    protected String mail;
    protected String age;
    protected String userName;
    protected String password;
    protected String language;
    protected String address;
    protected byte[] photo;

    public User(String name, String phone, String mail, String age, String userName, String password, String language, String address, byte[] photo)
    {
        this.name = name;
        this.phone = phone;
        this.mail = mail;
        this.age = age;
        this.userName = userName;
        this.password = password;
        this.language = language;
        this.address = address;
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getMail() {
        return mail;
    }

    public String getAge() {
        return age;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public String getLanguage() {
        return language;
    }

    public String getAddress() {
        return address;
    }

    public byte[] getPhoto() {
        return photo;
    }
}
