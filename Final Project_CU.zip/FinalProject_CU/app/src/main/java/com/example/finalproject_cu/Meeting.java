package com.example.finalproject_cu;

public class Meeting {
    private byte[] photo;
    private String name;
    private String age;
    private String phone;
    private String mail;
    private String place;
    private String q1;
    private String q2;

    private String userName;

    public Meeting(byte[] photo, String name, String age, String phone, String mail, String place, String q1, String q2, String userName) {
        this.photo = photo;
        this.name = name;
        this.age = age;
        this.phone = phone;
        this.mail = mail;
        this.place = place;
        this.q1 = q1;
        this.q2 = q2;
        this.userName = userName;
        }


    public byte[] getPhoto() {
        return photo;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getQ1() {
        return q1;
    }

    public void setQ1(String q1) {
        this.q1 = q1;
    }

    public String getQ2() {
        return q2;
    }

    public void setQ2(String q2) {
        this.q2 = q2;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }





}
