package com.example.finalproject_cu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class NewMeeting extends AppCompatActivity {

    ListView listView;
    MeetingsAdapter meetingsAdapter;
    CuDB db;
    SharedPreferences preferences;
    boolean isOld;
    private ArrayList<Meeting> meetingList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_meeting);

        preferences = getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
        isOld = preferences.getBoolean("isOld", true);

        listView= findViewById(R.id.listView);
        db = new CuDB(this);
        if (isOld)
            meetingList = db.selectAllForListView("volunteerUsers", "DaysPerWeek", "HoursPerMeeting");
        else
            meetingList = db.selectAllForListView("adultUsers","FamilyStatus","ActivitiesPreferring");

        meetingsAdapter = new MeetingsAdapter(this,R.layout.meeting_design, meetingList);
        listView.setAdapter(meetingsAdapter);

        listView.setOnItemClickListener();
    }






    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_for_list_view,menu);
        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.item1)
        {
            Intent intent= new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        if (id == R.id.item2)
        {
            Intent intent= new Intent(this, MyMeetings.class);
            startActivity(intent);
        }
        if (id == R.id.item3)
        {
            Intent intent= new Intent(this, AlertsSettings.class);
            startActivity(intent);
        }
        if (id == R.id.item4)
        {
            Intent intent= new Intent(this, MyDetails.class);
            startActivity(intent);
        }
        if (id == R.id.logOut)
            finish();
        //לבקו מה עושים אם זה נמצא בעמוד שלפניו זה לא יוצא!!!
        return true;
    }
}