package com.example.finalproject_cu;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;


public class MeetingsAdapter extends ArrayAdapter<Meeting> {
    private Context context;
    private int resource;
    private ArrayList<Meeting> items;
    private Meeting item;
    SharedPreferences preferences;
    boolean isOld;
    CuDB db;

    public MeetingsAdapter (@NonNull Context context, int resource, @NonNull ArrayList<Meeting> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.items = objects;
        db = new CuDB(this.context);
        preferences = context.getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
        isOld = preferences.getBoolean("isOld", true);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(resource,parent,false);
        ImageView photo = view.findViewById(R.id.MeetingPhoto);
        TextView name = view.findViewById(R.id.MeetingName);
        TextView age = view.findViewById(R.id.MeetingAge);
        TextView phone = view.findViewById(R.id.MeetingPhoneNum);
        TextView mail = view.findViewById(R.id.MeetingMail);
        TextView place = view.findViewById(R.id.MeetingPlace);
        TextView q1 = view.findViewById(R.id.MeetingQ1);
        TextView q2 = view.findViewById(R.id.MeetingQ2);

        item = items.get(position);
        String userName = item.getUserName();
        photo.setImageBitmap(BitmapFactory.decodeByteArray(item.getPhoto(), 0, item.getPhoto().length));
        name.setText("שם: " + item.getName());
        age.setText("גיל: " + item.getAge());
        phone.setText("טלפון: " + item.getPhone());
        mail.setText("מייל: " + item.getMail());
        place.setText("אזור מגורים: " + item.getPlace());

        //לבדוק אם בא לי לסנן לפי מיקום מגורים של הבן אדם או לא, ובהתאם לעשות שאילתה לפי מיקום. יש בשרד פרפרנסס מקום שמור של המשתמש הנוכחי

        if(!isOld)
        {
            ArrayList<String> familyStatus = db.selectByUserName("adultUsers", "FamilyStatus", userName);
            ArrayList<String> hobbies = db.selectByUserName("adultUsers", "ActivitiesPreferring", userName);
            q1.setText("מצב משפחתי: "+ familyStatus.get(0));
            q2.setText("העדפות תעסוקה: " + hobbies.get(0));
        }
        else
        {
            ArrayList<String> daysOfVolunteering = db.selectByUserName("volunteerUsers", "DaysPerWeek", userName);
            ArrayList<String> hoursPerMeeting = db.selectByUserName("volunteerUsers", "HoursPerMeeting", userName);
            q1.setText("ימי התנדבות: "+ daysOfVolunteering.get(0));
            q2.setText("כמות שעות למפגש: " + hoursPerMeeting.get(0));
        }

        return view;
    }
}
