package com.example.finalproject_cu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.name);
        SharedPreferences preferences = getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
        String name2 = preferences.getString("name", "");
        name.setText("שלום "+ name2+"!");
    }

    public void toListViewPage(View view) {
        Intent intent = new Intent(this, NewMeeting.class);
        startActivity(intent);
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_for_main_activity,menu);
        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.item1)
        {
            Intent intent= new Intent(this, NewMeeting.class);
            startActivity(intent);
        }
        if (id == R.id.item2)
        {
            Intent intent= new Intent(this, MyMeetings.class);
            startActivity(intent);
        }
        if (id == R.id.item3)
        {
            Intent intent= new Intent(this, AlertsSettings.class);
            startActivity(intent);
        }
        if (id == R.id.item4)
        {
            Intent intent= new Intent(this, MyDetails.class);
            startActivity(intent);
        }
        if (id == R.id.logOut)
            finish();
        //לבקו מה עושים אם זה נמצא בעמוד שלפניו זה לא יוצא!!!
        return true;
    }

}