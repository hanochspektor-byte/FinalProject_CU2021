package com.example.finalproject_cu;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Calendar;

public class RegisterPageAdult extends AppCompatActivity{
    CuDB cuDB;
    Spinner places;
    CheckBox[] checkBoxes= new CheckBox[4];
    EditText firstName, lastName, phoneNumber, email, userName, password, passwordCheck;
    TextView firstNameError, lastNameError, phoneNumberError,birthDateError, emailError, userNameError, passwordError, passwordCheckError;
    Button birthDate, imageView;
    String date="", languge= "", place="";
    int years;
    static Calendar calendar= Calendar.getInstance();
    static int year2= calendar.get(Calendar.YEAR);
    static int month2= calendar.get(Calendar.MONTH);
    static int day2= calendar.get(Calendar.DAY_OF_MONTH);
    Spinner q10,q20,q30;
    String a1="",a2="",a3="";
    Bitmap image;
    byte[] img;
    String age = "";

    DatePickerDialog.OnDateSetListener datePickerDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page_adult);
        cuDB = new CuDB(this);
        firstName= findViewById(R.id.firstName);
        lastName= findViewById(R.id.lastName);
        phoneNumber= findViewById(R.id.phoneNum);
        email= findViewById(R.id.email);
        birthDate= findViewById(R.id.birthDate);
        userName= findViewById(R.id.userName);
        password= findViewById(R.id.password);
        passwordCheck= findViewById(R.id.passwordCheck);
        firstNameError= findViewById(R.id.firstNameError);
        lastNameError= findViewById(R.id.lastNameError);
        phoneNumberError= findViewById(R.id.phoneError);
        emailError= findViewById(R.id.emailError);
        birthDateError= findViewById(R.id.birthDateError);
        userNameError= findViewById(R.id.userNameError);
        passwordError= findViewById(R.id.passwordError);
        passwordCheckError= findViewById(R.id.passwordCheckError);
        imageView= findViewById(R.id.takePhoto);
        places= findViewById(R.id.livingPlace);
        String[] items = new String[]{"ירושלים", "תל אביב", "חיפה", "ראשון לציון", "פתח תקווה", "אשדוד", "נתניה", "באר שבע", "בני ברק", "חולון", "רמת גן", "רחובות", "אשקלון", "בת ים", "בית שמש", "כפר סבא", "הרצליה", "חדרה"};
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_checked, items);
        places.setAdapter(adapter);
        checkBoxes[0]= findViewById(R.id.hebrewCB);
        checkBoxes[1]= findViewById(R.id.englishCB);
        checkBoxes[2]= findViewById(R.id.arabicCB);
        checkBoxes[3]= findViewById(R.id.russianCB);
        q10= findViewById(R.id.q10);
        q20= findViewById(R.id.q20);
        q30= findViewById(R.id.q30);

        String[] items1 = new String[]{"","נשוי עם ילדים", "אלמן","גרוש", "רווק"};
        final ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this,android.R.layout.simple_list_item_checked, items1);
        q10.setAdapter(adapter1);
        String[] items2 = new String[]{"","בפארק", "בבית","באיזור בילוי כגון מסעדה, קולנוע...", "בהליכות ברחוב", "אין העדפה"};
        final ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this,android.R.layout.simple_list_item_checked, items2);
        q20.setAdapter(adapter2);
        String[] items3 = new String[]{"","עזרה בהתניידות ממקום למקום", "בעבודות הבית הפשוטות","סתם לבלות", "עזרה בקניות"};
        final ArrayAdapter<String> adapter3 = new ArrayAdapter<>(this,android.R.layout.simple_list_item_checked, items3);
        q30.setAdapter(adapter3);


        birthDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DatePickerDialog dialog= new DatePickerDialog(RegisterPageAdult.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth, datePickerDialog, year2, month2, day2);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
       datePickerDialog= new DatePickerDialog.OnDateSetListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month= month+1;
                if(!(isCorrectDate(year, month, dayOfMonth)))
                    date="";
                else
                    {date= dayOfMonth + "/" + month + "/" + year;
                    birthDateError.setText(date);
                    birthDateError.setTextColor(Color.BLACK);
                    years= year2- year;
                    isOld();
                    age = getAge(year, month, dayOfMonth);

                    }


            }
        };

    }

    public void submit(View v) {
        if (TextUtils.isEmpty(firstName.getText().toString()) || !isAlpha(firstName.getText().toString())) {
            firstNameError.setText("אנא הכנס שם תקין.");
        } else {
            firstNameError.setText("");
        }
        if (TextUtils.isEmpty(lastName.getText().toString()) || !isAlpha(lastName.getText().toString())) {
            lastNameError.setText("אנא הכנס שם תקין.");
        } else {
            lastNameError.setText("");
        }
        if (TextUtils.isEmpty(phoneNumber.getText().toString()) || !isNum(phoneNumber.getText().toString()) || !(phoneNumber.length() ==9 || phoneNumber.length() ==10)) {
            phoneNumberError.setText("אנא הכנס מספר תקין.");
        } else {
            phoneNumberError.setText("");
        }
        if (TextUtils.isEmpty(email.getText().toString()) || !isEmail(email.getText().toString())) {
            emailError.setText("אנא הכנס כתובת מייל תקינה.");
        } else {
            emailError.setText("");
        }
        if (date == "") {
            birthDateError.setTextColor(Color.RED);
            birthDateError.setText("אנא הכנס תאריך תקין.");
        }
        if (TextUtils.isEmpty(userName.getText().toString())) {
            userNameError.setText("אנא הכנס שם משתמש תקין.");
        } else {
            userNameError.setText("");
        }
        if (TextUtils.isEmpty(password.getText().toString()) || password.getText().toString().length() != 8) {
            passwordError.setText("אנא הכנס סיסמה תקינה בארוך 8 מספרים.");
        } else {
            passwordError.setText("");
        }
        if (TextUtils.isEmpty(passwordCheck.getText().toString()) || !password.getText().toString().equals(passwordCheck.getText().toString())) {
            passwordCheckError.setText("הסיסמאות אינן תואמות.");
        } else {
            passwordCheckError.setText("");
        }

        place="";
        place= places.getSelectedItem().toString();

        languge="";
        for(int i= 0; i<checkBoxes.length; i++)
        {
            if (checkBoxes[i].isChecked())
                languge+= checkBoxes[i].getText().toString()+", ";
        }
        a1= q10.getSelectedItem().toString();
        a2= q20.getSelectedItem().toString();
        a3= q30.getSelectedItem().toString();

        if (firstNameError.getText().toString() == "" && lastNameError.getText().toString() == "" && phoneNumberError.getText().toString() == "" && birthDateError.getText().toString().equals(date) && emailError.getText().toString() == "" && userNameError.getText().toString() == "" && passwordError.getText().toString() == "" && passwordCheckError.getText().toString() == "")
        {
            if(place==""||languge==""||a1==""||a2==""||a3=="")
            {
                Toast.makeText(this, "אנא מל את כל השדות", Toast.LENGTH_SHORT).show();
            }
            else {
                String currentUserName = userName.getText().toString();
                boolean isExist = false;
                ArrayList<String> users = cuDB.selectAdultUserName();
                for (int i = 0; i < users.size(); i++) {
                    if (users.get(i).equals(currentUserName)) {
                        userNameError.setTextColor(Color.RED);
                        userNameError.setText("שם המשתמש קיים כבר במערכת!");
                        isExist = true;
                    }
                }
                if (!isExist) {
                    userNameError.setTextColor(Color.BLACK);
                    userNameError.setText("");
                    Adult adult = new Adult(firstName.getText().toString() + " " + lastName.getText().toString(), phoneNumber.getText().toString(), email.getText().toString(), age, userName.getText().toString(), password.getText().toString(), languge, place, img,a1, a2, a3);
                    cuDB.insertToAdult(adult);
                    Toast.makeText(this, "נרשמת בהצלחה!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this, SignInPage.class));
                    finish();
                }
            }
        }

    }


    public void cancel(View v)
    {
        finish();
    }

    public boolean isAlpha(String name)
    {
        String s=name.toLowerCase();
        for(int i=0; i<s.length();i++)
        {
            if((s.charAt(i)>='a' && s.charAt(i)<='z')||(s.charAt(i)>='א' && s.charAt(i)<='ת'))
            { continue; }
            else
            { return false; }
        }
        return true;
    }

    public boolean isNum(String name)
    {
        for(int i=0; i<name.length();i++)
        {
            if((name.charAt(i)>='0' && name.charAt(i)<='9'))
            { continue; }
            else
            { return false; }
        }
        return true;
    }

    public boolean isEmail(String email) {
        String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
        return email.matches(regex);
    }


    public void isOld()
    {
        if( years >= 65)
        {
            birthDateError.setText(date);
            birthDateError.setTextColor(Color.BLACK);
        }
        else
        {
            birthDateError.setTextColor(Color.RED);
            birthDateError.setText("מצטערים, אינך נמצא בטווח גילאים המתאים למערכת.");
        }
    }


    private boolean isCorrectDate(int year, int month, int dayOfMonth) {
        final int month3= month2+1;
        if(year>year2)
            return false;
        if (year<year2)
            return true;
        if(year==year2)
        {
            if(month>month3)
                return false;
            if (month<month3)
                return true;
            if(month==month3)
            {
                if(dayOfMonth>day2)
                    return false;
                if (dayOfMonth<day2)
                    return true;
            }
        }
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public String getAge(int year, int month, int dayOfMonth) {
        return Period.between(LocalDate.of(year, month, dayOfMonth), LocalDate.now()).getYears() + "." +
                Period.between(LocalDate.of(year, month, dayOfMonth), LocalDate.now()).getMonths();
    }

    static final int REQUEST_IMAGE_CAPTURE = 1;
    public void dispatchTakePictureIntent(View v) {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "אנא צלם תמונה תקינה", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            image = (Bitmap) extras.get("data");
            imageView.setBackground(new BitmapDrawable(getResources(), image));
            imageView.setText("");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            image.compress(Bitmap.CompressFormat.PNG, 100, bos);
            img = bos.toByteArray();
        }
    }


}