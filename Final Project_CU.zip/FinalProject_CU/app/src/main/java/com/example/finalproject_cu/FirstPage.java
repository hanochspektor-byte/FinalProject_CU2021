package com.example.finalproject_cu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FirstPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_page);
    }

    public void toSignIn(View view) {
        Intent intent= new Intent(this, SignInPage.class);
        startActivity(intent);
    }

    public void toRegisterForAdult(View view) {
        Intent intent= new Intent(this, RegisterPageAdult.class);
        startActivity(intent);
    }

    public void toRegisterForVolunteer(View view) {
        Intent intent= new Intent(this, RegisterPageVolunteer.class);
        startActivity(intent);
    }
}