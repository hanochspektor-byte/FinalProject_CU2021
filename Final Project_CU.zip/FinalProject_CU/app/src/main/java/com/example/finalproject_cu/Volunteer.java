package com.example.finalproject_cu;

import android.graphics.Bitmap;

public class Volunteer extends User {

    private String hoursEachTime;
    private String daysPerWeek;
    private String giveHelpIn;

    public Volunteer(String name, String phone, String mail, String age, String userName, String password, String language, String address, byte[] photo, String hoursEachTime, String daysPerWeek, String giveHelpIn)
    {
        super(name, phone, mail, age, userName, password, language, address, photo);
        this.hoursEachTime= hoursEachTime;
        this.daysPerWeek= daysPerWeek;
        this.giveHelpIn= giveHelpIn;
    }

    public String getHoursEachTime() {
        return hoursEachTime;
    }

    public String getDaysPerWeek() {
        return daysPerWeek;
    }

    public String getGiveHelpIn() {
        return giveHelpIn;
    }


}
